# 💖 Kimvherly H. Baaco - Portfolio Website

A professional, responsive **Flask-based portfolio website** for **Kimvherly H. Baaco**, a Bachelor of Science in Information Technology student. Features an elegant pink-and-white feminine theme, a complete project showcase, and an **AI-powered Portfolio Assistant** chatbot.

---

## ✨ Features

- 🎨 **Modern Pink & White Design** — elegant, feminine, professional
- 📱 **Fully Responsive** — works beautifully on phones, tablets, and desktops
- 🏠 **Homepage** — hero section, KHB logo, featured skills
- 👩‍🎓 **About Page** — personal info, career goal, interests, education timeline
- 💻 **Skills Page** — animated progress bars and skill cards
- 🚀 **Projects Page** — 4 project showcases with tech tags
- 📧 **Contact Page** — working contact form with validation
- 🤖 **AI Portfolio Assistant** — chatbot that answers questions about Kimvherly
- 🧩 **Flask Template Inheritance** — clean `base.html` with reusable navbar/footer
- 🔐 **Environment Variables** — secure API key management

---

## 📂 Project Structure

```
portfolio_flask/
├── app.py                    # Main Flask application
├── requirements.txt          # Python dependencies
├── .env.example              # Environment variable template
├── README.md                 # This file
├── static/
│   ├── css/
│   │   └── style.css         # Main stylesheet
│   ├── js/
│   │   └── chatbot.js        # AI Assistant frontend logic
│   └── images/               # Image assets folder
└── templates/
    ├── base.html             # Parent template (navbar + footer)
    ├── home.html             # Homepage
    ├── about.html            # About page
    ├── skills.html           # Skills page
    ├── projects.html         # Projects page
    ├── contact.html          # Contact page
    └── ai_assistant.html     # AI chatbot page
```

---

## 🚀 Setup & Installation

### 1️⃣ Prerequisites
- **Python 3.9+** installed on your system
- **pip** (comes bundled with Python)

### 2️⃣ Clone or Download the project

```bash
cd portfolio_flask
```

### 3️⃣ Create a virtual environment (recommended)

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**macOS / Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### 4️⃣ Install dependencies

```bash
pip install -r requirements.txt
```

### 5️⃣ Set up environment variables

Copy the example file and rename it:

**Windows:**
```bash
copy .env.example .env
```

**macOS / Linux:**
```bash
cp .env.example .env
```

Then open `.env` and (optionally) add your OpenAI API key:

```env
SECRET_KEY=your-random-secret-key-here
OPENAI_API_KEY=sk-your-real-openai-key-here
OPENAI_MODEL=gpt-4o-mini
```

> 💡 **Note:** The chatbot **works without an OpenAI key** — it uses a smart rule-based fallback! Add a real key for more natural conversations.

### 6️⃣ Run the application

```bash
python app.py
```

Open your browser and visit: **http://127.0.0.1:5000**

---

## 🤖 AI Assistant Setup

The AI Portfolio Assistant supports two modes:

### Mode 1: Local Rule-Based (Default — No API key needed) ✅
Works out of the box! Detects keywords in user messages and returns relevant pre-written responses about Kimvherly.

### Mode 2: OpenAI-Powered 🚀
For more natural, dynamic answers:

1. Sign up at [platform.openai.com](https://platform.openai.com/)
2. Generate an API key
3. Add it to your `.env` file as `OPENAI_API_KEY=sk-...`
4. Restart the Flask app

---

## 🎨 Color Palette

| Role             | Color     |
|------------------|-----------|
| Primary          | `#EC4899` |
| Secondary        | `#F9A8D4` |
| Background       | `#FFFDFD` |
| Card Background  | `#FCE7F3` |
| Text             | `#1F2937` |
| Accent           | `#BE185D` |

---

## 🧩 Technologies Used

- **Backend:** Python, Flask, Jinja2
- **Frontend:** HTML5, CSS3, JavaScript (Vanilla)
- **AI:** OpenAI API (with local fallback)
- **Fonts:** Poppins, Playfair Display
- **Icons:** Font Awesome 6

---

## 📄 Pages Overview

| Route             | Description                                  |
|-------------------|----------------------------------------------|
| `/`               | Homepage with hero & featured skills         |
| `/about`          | About page with personal info & education   |
| `/skills`         | Skills page with animated progress bars      |
| `/projects`       | Projects showcase                            |
| `/contact`        | Contact form & info                          |
| `/ai-assistant`   | AI Portfolio Assistant chatbot               |
| `/chat`           | POST API endpoint for the chatbot            |

---

## 💡 Customization

- **Update personal info:** Edit `PORTFOLIO_KNOWLEDGE` in `app.py`
- **Change colors:** Modify CSS variables at the top of `static/css/style.css`
- **Add projects:** Append to `projects_data` in `app.py`
- **Add a profile photo:** Place your photo in `static/images/` and update the `<div class="profile-placeholder">` blocks in `home.html` and `about.html` to use `<img>` tags

---

## 👩‍💻 Author

**Kimvherly H. Baaco**
Bachelor of Science in Information Technology
📧 kimvherlyb@example.com
🌐 [GitHub](https://github.com/kimvherlybaaco) | [LinkedIn](https://linkedin.com/in/kimvherlybaaco)

---

## 📜 License

This project is created for academic purposes as part of a school requirement.
Feel free to use it as a learning reference. 💖

---

Made with 💖 and Flask
