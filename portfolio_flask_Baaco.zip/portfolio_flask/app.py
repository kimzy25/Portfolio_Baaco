"""
=====================================================
  Kimvherly H. Baaco - Personal Portfolio Website
  Flask Backend Application
=====================================================
  Author : Kimvherly H. Baaco
  Course : Bachelor of Science in Information Technology
  Description:
      Main Flask application that handles routing,
      template rendering, contact form submissions,
      and the AI Portfolio Assistant chat endpoint.
=====================================================
"""

# ---- Standard Library Imports ----
import os
from datetime import datetime

# ---- Third-Party Imports ----
from flask import Flask, render_template, request, jsonify, flash, redirect, url_for
from dotenv import load_dotenv

# Load environment variables from .env file (if it exists)
load_dotenv()

# ---- Initialize Flask Application ----
app = Flask(__name__)

# Secret key is used for session security and flash messages.
# In production, set this in your .env file.
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'khb-portfolio-secret-key-2026')


# =====================================================
# Knowledge Base for the AI Assistant (Fallback Mode)
# =====================================================
# This dictionary contains pre-defined responses about
# Kimvherly so the chatbot can answer even if no
# OpenAI API key is configured.
# =====================================================
PORTFOLIO_KNOWLEDGE = {
    "name": "Kimvherly H. Baaco",
    "title": "BS Information Technology Student | Aspiring Web Developer",
    "intro": (
        "Kimvherly H. Baaco is a Bachelor of Science in Information Technology "
        "student passionate about web development, software development, and emerging "
        "technologies. She enjoys creating user-friendly digital solutions and "
        "continuously expanding her technical skills through academic projects and "
        "hands-on learning experiences."
    ),
    "career_goal": (
        "To become a skilled IT professional specializing in web development, "
        "software engineering, and innovative technology solutions while contributing "
        "to impactful projects that improve people's lives."
    ),
    "skills": [
        "HTML5", "CSS3", "JavaScript", "Python", "Flask",
        "MySQL", "Git & GitHub", "Responsive Web Design",
        "Problem Solving", "Team Collaboration"
    ],
    "interests": [
        "Web Development", "UI/UX Design", "Artificial Intelligence",
        "Software Development", "Emerging Technologies"
    ],
    "projects": [
        {
            "name": "Clinic Management System",
            "description": "A web-based healthcare management platform that streamlines patient records, appointments, and clinic operations."
        },
        {
            "name": "Student Information System",
            "description": "A system for managing student records, enrollment, grades, and academic information."
        },
        {
            "name": "Portfolio Website",
            "description": "A responsive personal portfolio website developed using Flask, HTML, CSS, and JavaScript."
        },
        {
            "name": "AI-Powered Web Application",
            "description": "An intelligent web application that integrates artificial intelligence to provide smart recommendations and user assistance."
        }
    ]
}


# =====================================================
# ROUTES
# =====================================================

@app.route('/')
def home():
    """Render the Homepage with hero section, intro, and featured skills."""
    return render_template('home.html', active_page='home')


@app.route('/about')
def about():
    """Render the About page with personal info, career goal, and interests."""
    return render_template(
        'about.html',
        active_page='about',
        interests=PORTFOLIO_KNOWLEDGE['interests']
    )


@app.route('/skills')
def skills():
    """Render the Skills page with technical skill cards and progress bars."""
    # Each skill has a name, font-awesome icon class, and proficiency percentage.
    skills_data = [
        {"name": "HTML5", "icon": "fa-brands fa-html5", "level": 95},
        {"name": "CSS3", "icon": "fa-brands fa-css3-alt", "level": 90},
        {"name": "JavaScript", "icon": "fa-brands fa-js", "level": 80},
        {"name": "Python", "icon": "fa-brands fa-python", "level": 85},
        {"name": "Flask", "icon": "fa-solid fa-flask", "level": 80},
        {"name": "MySQL", "icon": "fa-solid fa-database", "level": 78},
        {"name": "Git & GitHub", "icon": "fa-brands fa-github", "level": 82},
        {"name": "Responsive Web Design", "icon": "fa-solid fa-mobile-screen", "level": 88},
        {"name": "Problem Solving", "icon": "fa-solid fa-lightbulb", "level": 90},
        {"name": "Team Collaboration", "icon": "fa-solid fa-users", "level": 92},
    ]
    return render_template('skills.html', active_page='skills', skills=skills_data)


@app.route('/projects')
def projects():
    """Render the Projects page with project cards."""
    projects_data = [
        {
            "name": "Clinic Management System",
            "description": "A web-based healthcare management platform that streamlines patient records, appointments, and clinic operations.",
            "technologies": ["PHP", "MySQL", "HTML5", "CSS3", "JavaScript"],
            "icon": "fa-solid fa-stethoscope",
            "github": "https://github.com/kimvherlybaaco",
            "demo": "#"
        },
        {
            "name": "Student Information System",
            "description": "A system for managing student records, enrollment, grades, and academic information.",
            "technologies": ["Python", "Flask", "MySQL", "Bootstrap"],
            "icon": "fa-solid fa-graduation-cap",
            "github": "https://github.com/kimvherlybaaco",
            "demo": "#"
        },
        {
            "name": "Portfolio Website",
            "description": "A responsive personal portfolio website developed using Flask, HTML, CSS, and JavaScript.",
            "technologies": ["Flask", "HTML5", "CSS3", "JavaScript", "Jinja2"],
            "icon": "fa-solid fa-laptop-code",
            "github": "https://github.com/kimvherlybaaco",
            "demo": "#"
        },
        {
            "name": "AI-Powered Web Application",
            "description": "An intelligent web application that integrates artificial intelligence to provide smart recommendations and user assistance.",
            "technologies": ["Python", "Flask", "OpenAI API", "JavaScript"],
            "icon": "fa-solid fa-robot",
            "github": "https://github.com/kimvherlybaaco",
            "demo": "#"
        }
    ]
    return render_template('projects.html', active_page='projects', projects=projects_data)


@app.route('/contact', methods=['GET', 'POST'])
def contact():
    """
    Render the Contact page.
    Handles both GET (display form) and POST (process form submission).
    """
    success = False
    if request.method == 'POST':
        # Retrieve form data
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip()
        subject = request.form.get('subject', '').strip()
        message = request.form.get('message', '').strip()

        # Simple server-side validation
        if full_name and email and subject and message:
            # In a real project, you'd save this to a database or send an email.
            # For now, we just log it to the console.
            print(f"[CONTACT FORM] From: {full_name} <{email}> | Subject: {subject}")
            print(f"Message: {message}")
            success = True
            flash('Your message has been sent successfully! Thank you for reaching out. 💖', 'success')
        else:
            flash('Please fill in all required fields.', 'error')

    return render_template('contact.html', active_page='contact', success=success)


@app.route('/ai-assistant')
def ai_assistant():
    """Render the AI Portfolio Assistant chat page."""
    return render_template('ai_assistant.html', active_page='ai_assistant')


# =====================================================
# AI CHAT API ENDPOINT
# =====================================================

@app.route('/chat', methods=['POST'])
def chat():
    """
    Receives JSON {"message": "..."} from the chatbot frontend
    and returns a JSON response containing the AI's reply.

    If an OpenAI API key is configured in the environment,
    the request is forwarded to OpenAI. Otherwise, a smart
    rule-based fallback response is returned so the assistant
    still works out-of-the-box for school submissions.
    """
    data = request.get_json(silent=True) or {}
    user_message = (data.get('message') or '').strip()

    if not user_message:
        return jsonify({"reply": "Please type a question so I can help you! 💕"}), 400

    # Attempt to use OpenAI if an API key is configured
    openai_key = os.getenv('OPENAI_API_KEY')

    if openai_key:
        try:
            reply = generate_openai_response(user_message, openai_key)
            return jsonify({"reply": reply})
        except Exception as e:
            # If the API call fails, gracefully fall back to local responses
            print(f"[OpenAI Error] {e} -- falling back to local responses.")

    # Fallback: rule-based local response
    reply = generate_local_response(user_message)
    return jsonify({"reply": reply})


def generate_openai_response(user_message, api_key):
    """
    Sends the user's message to the OpenAI Chat Completions API
    along with a system prompt describing Kimvherly's portfolio.

    To enable this, set OPENAI_API_KEY in your .env file.
    Install the openai package: pip install openai
    """
    # Import inside the function so the app still works without openai installed
    from openai import OpenAI

    client = OpenAI(api_key=api_key)

    system_prompt = (
        "You are the AI Portfolio Assistant for Kimvherly H. Baaco, "
        "a Bachelor of Science in Information Technology student and aspiring web developer. "
        f"Here is her profile information: {PORTFOLIO_KNOWLEDGE}. "
        "Answer questions about Kimvherly's background, skills, projects, education, "
        "and career goals in a friendly, professional, and helpful manner. "
        "Keep responses concise (2-4 sentences) unless asked for more detail."
    )

    response = client.chat.completions.create(
        model=os.getenv('OPENAI_MODEL', 'gpt-4o-mini'),
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message}
        ],
        max_tokens=400,
        temperature=0.7,
    )

    return response.choices[0].message.content.strip()


def generate_local_response(user_message):
    """
    Rule-based fallback responses that work without any API key.
    Detects keywords in the user's question and returns a relevant answer.
    """
    msg = user_message.lower()

    # Greetings
    if any(word in msg for word in ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening']):
        return ("Hello there! 💖 I'm the AI Portfolio Assistant. "
                "Feel free to ask me anything about Kimvherly — her skills, projects, education, or career goals!")

    # About Kimvherly
    if 'who' in msg or 'about' in msg or 'tell me' in msg or 'introduce' in msg:
        return PORTFOLIO_KNOWLEDGE['intro']

    # Skills / Technologies
    if 'skill' in msg or 'technolog' in msg or 'language' in msg or 'use' in msg or 'stack' in msg:
        skills_list = ", ".join(PORTFOLIO_KNOWLEDGE['skills'])
        return f"Kimvherly is skilled in: {skills_list}. She's especially passionate about web development and Python/Flask. 💻"

    # Projects
    if 'project' in msg or 'work' in msg or 'built' in msg or 'developed' in msg or 'portfolio' in msg:
        proj_names = ", ".join([p['name'] for p in PORTFOLIO_KNOWLEDGE['projects']])
        return (f"Kimvherly has developed several projects including: {proj_names}. "
                "You can view detailed descriptions on the Projects page! 🚀")

    # Education
    if 'education' in msg or 'school' in msg or 'study' in msg or 'course' in msg or 'degree' in msg:
        return ("Kimvherly is currently pursuing a Bachelor of Science in Information Technology, "
                "where she's building strong foundations in programming, databases, and web development. 🎓")

    # Career
    if 'career' in msg or 'goal' in msg or 'future' in msg or 'aspiration' in msg or 'dream' in msg:
        return PORTFOLIO_KNOWLEDGE['career_goal']

    # Interests
    if 'interest' in msg or 'hobby' in msg or 'passion' in msg or 'like' in msg:
        interests_list = ", ".join(PORTFOLIO_KNOWLEDGE['interests'])
        return f"Kimvherly is interested in: {interests_list}. ✨"

    # Contact
    if 'contact' in msg or 'reach' in msg or 'email' in msg or 'message' in msg:
        return ("You can reach Kimvherly via the Contact page — email, Facebook, GitHub, "
                "and LinkedIn are all listed there! 📧")

    # Thanks
    if 'thank' in msg or 'thanks' in msg:
        return "You're very welcome! 💕 Let me know if you have more questions about Kimvherly's portfolio."

    # Default
    return ("That's a great question! I can help you learn about Kimvherly's background, "
            "skills, projects, education, or career goals. Try asking: "
            "\"Tell me about Kimvherly\" or \"What projects has Kimvherly built?\" 💡")


# =====================================================
# Template Context Processor
# =====================================================
@app.context_processor
def inject_globals():
    """Inject common variables into every template (e.g., current year for footer)."""
    return {
        'current_year': datetime.now().year,
        'owner_name': 'Kimvherly H. Baaco'
    }


# =====================================================
# Error Handlers
# =====================================================
@app.errorhandler(404)
def not_found(e):
    """Custom 404 page — gracefully redirects to home."""
    return render_template('home.html', active_page='home'), 404


# =====================================================
# Application Entry Point
# =====================================================
if __name__ == '__main__':
    # Debug mode for development — turn OFF in production!
    app.run(debug=True, host='0.0.0.0', port=5000)
