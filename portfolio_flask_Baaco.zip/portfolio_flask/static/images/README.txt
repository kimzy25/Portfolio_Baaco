Place your profile photos and project screenshots in this folder.

Suggested files:
  - profile.jpg          (your professional photo)
  - project-1.png        (Clinic Management System screenshot)
  - project-2.png        (Student Information System screenshot)
  - project-3.png        (Portfolio Website screenshot)
  - project-4.png        (AI-Powered Web Application screenshot)

To display them in templates, use:
  <img src="{{ url_for('static', filename='images/profile.jpg') }}" alt="Kimvherly">
