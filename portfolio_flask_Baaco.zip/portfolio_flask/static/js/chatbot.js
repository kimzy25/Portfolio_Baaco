/* =====================================================
   KHB PORTFOLIO - AI ASSISTANT CHATBOT JS
   Handles chat UI, message sending, and API calls
   ===================================================== */

(function () {
    // Get DOM elements
    const chatForm = document.getElementById('chatForm');
    const userInput = document.getElementById('userInput');
    const chatMessages = document.getElementById('chatMessages');
    const typingIndicator = document.getElementById('typingIndicator');
    const chips = document.querySelectorAll('.chip');

    // Guard: only run on the AI Assistant page
    if (!chatForm || !userInput || !chatMessages) return;

    // ---------------------------------------------------
    // Append a new message bubble to the chat window
    // ---------------------------------------------------
    function appendMessage(text, sender = 'bot') {
        const wrapper = document.createElement('div');
        wrapper.className = `message message-${sender}`;

        const avatar = document.createElement('div');
        avatar.className = 'msg-avatar';
        avatar.innerHTML = sender === 'bot'
            ? '<i class="fa-solid fa-robot"></i>'
            : '<i class="fa-solid fa-user"></i>';

        const content = document.createElement('div');
        content.className = 'msg-content';
        content.textContent = text;

        wrapper.appendChild(avatar);
        wrapper.appendChild(content);
        chatMessages.appendChild(wrapper);

        // Auto-scroll to the latest message
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // ---------------------------------------------------
    // Show / Hide the "typing..." indicator
    // ---------------------------------------------------
    function showTyping(show) {
        if (typingIndicator) {
            typingIndicator.style.display = show ? 'flex' : 'none';
            if (show) chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }

    // ---------------------------------------------------
    // Send a message to the Flask /chat endpoint
    // ---------------------------------------------------
    async function sendMessage(message) {
        // Show user's message immediately
        appendMessage(message, 'user');
        showTyping(true);

        try {
            const response = await fetch('/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: message })
            });

            const data = await response.json();
            showTyping(false);

            // Small natural delay so the answer feels less robotic
            setTimeout(() => {
                appendMessage(data.reply || 'Sorry, I could not generate a response.', 'bot');
            }, 200);

        } catch (err) {
            console.error('Chat error:', err);
            showTyping(false);
            appendMessage(
                'Oops! Something went wrong while contacting the server. Please try again. 💖',
                'bot'
            );
        }
    }

    // ---------------------------------------------------
    // Handle form submission
    // ---------------------------------------------------
    chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const text = userInput.value.trim();
        if (!text) return;
        sendMessage(text);
        userInput.value = '';
        userInput.focus();
    });

    // ---------------------------------------------------
    // Handle clicks on suggested question chips
    // ---------------------------------------------------
    chips.forEach(chip => {
        chip.addEventListener('click', () => {
            const question = chip.getAttribute('data-q');
            sendMessage(question);
        });
    });

    // Focus the input field on page load
    userInput.focus();
})();
